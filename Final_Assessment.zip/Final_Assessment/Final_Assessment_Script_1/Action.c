Action()
{
	int tt=10;
	long file,file2;
	

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	

	lr_start_transaction("Launch");

	web_url("banking_2", 
		"URL=http://localhost/banking/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Launch",LR_AUTO);

	lr_think_time(14);



	web_custom_request("r11.o.lencr.org_3", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04\\xA1\\xBCk\\xADIM\\xD7\\x10T7\\xFA:\\x1E\\x80\\xCE\\x03\\x14", 
		LAST);



	web_custom_request("r11.o.lencr.org_4", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\x1AD\\x9CN>g\\xE5\\x04\\xD9\\xE4\\xC9f*0\\x07\\x8C3", 
		LAST);

	web_custom_request("ocsp.digicert.com_3", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x07\n\\xED\\xD4\\xBB:9\\x0E9ea\\x16\\xBF\\xAA\\xC3\\xBE", 
		LAST);



	lr_think_time(tt);


	lr_start_transaction("T02_Open_Account");

	web_url("customer_reg_form.php", 
		"URL=http://localhost/banking/customer_reg_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);

	lr_think_time(tt);



	lr_end_transaction("T02_Open_Account",LR_AUTO);

	lr_start_transaction("T03_Fill_Details");

	web_reg_save_param("C_city",
		"LB=span>City : ",
		"RB=<br> </span>",
		LAST);

	
	

	web_submit_data("customer_reg_form.php_2", 
		"Action=http://localhost/banking/customer_reg_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_reg_form.php", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=name", "Value={P_name}", ENDITEM, 
		"Name=gender", "Value=Male", ENDITEM, 
		"Name=mobile", "Value={P_mobile}", ENDITEM, 
		"Name=email", "Value={P_email}", ENDITEM, 
		"Name=landline", "Value={P_landline}", ENDITEM, 
		"Name=dob", "Value={P_dob}", ENDITEM, 
		"Name=pan_no", "Value={P_pan_no}", ENDITEM, 
		"Name=citizenship", "Value={P_citizenship}", ENDITEM, 
		"Name=homeaddrs", "Value={P_homeaddrs}", ENDITEM, 
		"Name=officeaddrs", "Value={P_officeaddrs}", ENDITEM, 
		"Name=country", "Value=US", ENDITEM, 
		"Name=state", "Value={P_state}", ENDITEM, 
		"Name=city", "Value={P_city}", ENDITEM, 
		"Name=pin", "Value={P_pin}", ENDITEM, 
		"Name=arealoc", "Value=candor", ENDITEM, 
		"Name=nominee_name", "Value={P_nominee_name}", ENDITEM, 
		"Name=nominee_ac_no", "Value={P_nominee_ac_no}", ENDITEM, 
		"Name=acctype", "Value={P_acctype}", ENDITEM, 
		"Name=submit", "Value=Submit", ENDITEM, 
		LAST);

	lr_end_transaction("T03_Fill_Details",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("T04_Click_Confirm");
	

	web_reg_save_param("C_Application_number",
		"LB=nApplication number : ",
		"RB=\\",
		LAST);

	

	web_submit_data("cust_regfrm_confirm.php", 
		"Action=http://localhost/banking/cust_regfrm_confirm.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/cust_regfrm_confirm.php", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=cnfrm-submit", "Value=Confirm", ENDITEM, 
		LAST);

	lr_think_time(tt);

	web_url("Home", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/cust_regfrm_confirm.php", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("T04_Click_Confirm",LR_AUTO);
	
	lr_output_message(lr_eval_string("{P_name}"));
	lr_output_message(lr_eval_string("{P_dob}"));
	
	lr_output_message(lr_eval_string("{P_pan_no}"));
	lr_output_message(lr_eval_string("{P_mobile}"));
	lr_output_message(lr_eval_string("{C_Application_number}"));
	
	
	file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Assessment_Script_1\\Appications.txt","a+");
	
	fprintf(file,"%s",lr_eval_string("{C_Application_number},{P_pan_no},{P_name},{P_mobile},{P_email},{P_landline},{P_dob},{P_citizenship},{P_homeaddrs},{P_officeaddrs},{P_nominee_name},{P_pin},{P_nominee_ac_no},{P_acctype},{P_city},{P_state}\n"));
	fclose(file);
	
	
	
	
	file2 = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Assessment_Script_1\\P_application_no.txt","a+");
	
	fprintf(file2,"%s",lr_eval_string("{C_Application_number},{P_name},{P_dob},{P_pan_no},{P_mobile}\n"));
	fclose(file2);

	return 0;
}